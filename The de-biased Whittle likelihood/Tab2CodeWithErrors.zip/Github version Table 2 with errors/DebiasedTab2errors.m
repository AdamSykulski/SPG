N = 1200; %length of time series (50 days of hourly observations)
load drifterdata.mat % load the data
options=optimset('GradObj','on'); % Fminsearch choices
xb=[.05 1 .1]; % initial Matern values
omega=0:2*pi/N:2*pi*(1-1/N); omega=fftshift(omega); omega(1:floor(N/2))=omega(1:floor(N/2))-2*pi; % fourier coefficients, correct for odd or even N
for ii = 1:3
    ii
    Z=reshape(drifterdata(ii,3,:),N,1); % complex velocities of drifter ii
    if ii == 1
        Z = conj(Z); % for the Atlantic drifter the inertial side of the spectrum is on the positive side, so we take the conjugate to flip this
    end
    tic; % using fminsearchbnd, the parameters are rescaled to all start at 1, lower and upper bounds as permitted by the stochastic process
    %% DEBIASED WHITTLE
    JZ = fft(Z)/sqrt(N); SZ = (abs(JZ)).^2; SZ=SZ(1:floor(N/2)+1);
    x1=fminsearchbnd(@(x) debiasedwhittle(x,SZ',N),xb,[0 0.5001 0],[inf 2.5 N/(2*pi)],options);    
    time1(ii)=toc;
    FI=hessian(@(x) debiasedwhittle(x,SZ',N), x1); IFI1 = inv(FI);    
    omegaR = -pi:0.01:pi;
    MaternDiv1 = 2*x1(1)./((1/x1(3))^2+omegaR.^2).^x1(2);
    MaternDiv2 = -log(omegaR.^2+(1/x1(3))^2).*x1(1)^2./((1/x1(3))^2+omegaR.^2).^x1(2);
    MaternDiv3 = 2*(1/x1(3)^3)*x1(2)*x1(1)^2./((1/x1(3))^2+omegaR.^2).^(x1(2)+1);
    Div1 = zeros(1,length(omega)); Div2 = zeros(1,length(omega)); Div3 = zeros(1,length(omega));
    for kk = 1:length(omega)
        FK = (1/(2*pi*N))*sin(N*(omega(kk)-omegaR)/2).^2./sin((omega(kk)-omegaR)/2).^2;
        Div1(kk)=(2*pi/length(omegaR))*sum(MaternDiv1.*FK);
        Div2(kk)=(2*pi/length(omegaR))*sum(MaternDiv2.*FK);
        Div3(kk)=(2*pi/length(omegaR))*sum(MaternDiv3.*FK);
    end
    x1a = x1; x1a(3) = 1/x1a(3);
    acv=maternacvs(x1a,N,1); % autocovariance sequence
    ESF2=2*fft(acv.*(1-(0:N-1)/N))-acv(1); ESF2 = abs(real(fftshift(ESF2)));
    MM = zeros(3,3);
    for kk = 1:length(omega)
        for ll = 1:length(omega)
            KK = VarQuad(x1,omega(kk),omega(ll),N);
            MM(1,1) = Div1(kk)/(ESF2(kk)^2)*Div1(ll)/(ESF2(ll)^2)*KK+MM(1,1);
            MM(2,2) = Div2(kk)/(ESF2(kk)^2)*Div2(ll)/(ESF2(ll)^2)*KK+MM(2,2);
            MM(3,3) = Div3(kk)/(ESF2(kk)^2)*Div3(ll)/(ESF2(ll)^2)*KK+MM(3,3);
            MM(1,2) = Div1(kk)/(ESF2(kk)^2)*Div2(ll)/(ESF2(ll)^2)*KK+MM(1,2);
            MM(1,3) = Div1(kk)/(ESF2(kk)^2)*Div3(ll)/(ESF2(ll)^2)*KK+MM(1,3);
            MM(2,3) = Div2(kk)/(ESF2(kk)^2)*Div3(ll)/(ESF2(ll)^2)*KK+MM(2,3);
        end
    end
    MM(2,1) = MM(1,2); MM(3,1) = MM(1,3); MM(3,2) = MM(2,3);
    IFI1b=IFI1*MM*IFI1;
    nabla(1)=0.5*x1(1)*x1(3)^(2*x1(2));
    nabla(3)=0.5*x1(2)*x1(1)^2*x1(3)^(2*x1(2)-1);
    nabla(2)=0.5*log(x1(3))*x1(1)^2*x1(3)^(2*x1(2));
    diffv1 = nabla*IFI1*nabla'; % just from Hessian
    diffv1b = nabla*IFI1b*nabla'; % full method from Section 6.2
    %% REGULAR WHITTLE LIKELIHOOD
    tic; % using fminsearchbnd, the parameters are rescaled to all start at 1, lower and upper bounds as permitted by the stochastic process
    JZ = fft(Z)/sqrt(N); SZ = (abs(JZ)).^2; SZ=SZ(1:floor(N/2)+1);
    x2=fminsearchbnd(@(x) whittle(x,SZ',N),xb,[0 0.5001 0],[inf 2.5 N/(2*pi)],options);
    time2(ii)=toc;
    FI=hessian(@(x) whittle(x,SZ',N), x2); IFI2 = inv(FI);
    MaternDiv1 = 2*x2(1)./((1/x2(3))^2+omega.^2).^x2(2);
    MaternDiv2 = -log(omega.^2+(1/x2(3))^2).*x2(1)^2./((1/x2(3))^2+omega.^2).^x2(2);
    MaternDiv3 = 2*(1/x2(3)^3)*x2(2)*x2(1)^2./((1/x2(3))^2+omega.^2).^(x2(2)+1);
    MaternVal = x2(1)^2./((1/x2(3))^2+omega.^2).^x2(2);
    MM = zeros(3,3);
    for kk = 1:length(omega)
        for ll = 1:length(omega)
        KK = VarQuad(x2,omega(kk),omega(ll),N);
        MM(1,1) = MaternDiv1(kk)*(1/MaternVal(kk)^2)*MaternDiv1(ll)*(1/MaternVal(ll)^2)*KK+MM(1,1);
        MM(2,2) = MaternDiv2(kk)*(1/MaternVal(kk)^2)*MaternDiv2(ll)*(1/MaternVal(ll)^2)*KK+MM(2,2);
        MM(3,3) = MaternDiv3(kk)*(1/MaternVal(kk)^2)*MaternDiv3(ll)*(1/MaternVal(ll)^2)*KK+MM(3,3);
        MM(1,2) = MaternDiv1(kk)*(1/MaternVal(kk)^2)*MaternDiv2(ll)*(1/MaternVal(ll)^2)*KK+MM(1,2);
        MM(1,3) = MaternDiv1(kk)*(1/MaternVal(kk)^2)*MaternDiv3(ll)*(1/MaternVal(ll)^2)*KK+MM(1,3);
        MM(2,3) = MaternDiv2(kk)*(1/MaternVal(kk)^2)*MaternDiv3(ll)*(1/MaternVal(ll)^2)*KK+MM(2,3);
        end
    end
    MM(2,1) = MM(1,2); MM(3,1) = MM(1,3); MM(3,2) = MM(2,3);
    IFI2b=IFI2*MM*IFI2;
    nabla(1)=0.5*x2(1)*x2(3)^(2*x2(2));
    nabla(3)=0.5*x2(2)*x2(1)^2*x2(3)^(2*x2(2)-1);
    nabla(2)=0.5*log(x2(3))*x2(1)^2*x2(3)^(2*x2(2));
    diffv2 = nabla*IFI2*nabla'; % just from Hessian
    diffv2b = nabla*IFI2b*nabla'; % full method from Section 6.2
    %% MAXIMUM LIKELIHOOD
    tic; % using fminsearchbnd, the parameters are rescaled to all start at 1, lower and upper bounds as permitted by the stochastic process
    Z1=0.5*(hilbert(real(Z))+1i.*hilbert(imag(Z)));
    x3=fminsearchbnd(@(x) maximumlikelihood(x,real(Z1),imag(Z1),N),xb,[0 0.5001 0],[inf 2.5 N/(2*pi)],options);
    time3(ii)=toc;
    FI=hessian(@(x) maximumlikelihood(x,real(Z1),imag(Z1),N), x3); IFI3 = inv(FI);
    nabla(1)=0.5*x3(1)*x3(3)^(2*x3(2));
    nabla(3)=0.5*x3(2)*x3(1)^2*x3(3)^(2*x3(2)-1);
    nabla(2)=0.5*log(x3(3))*x3(1)^2*x3(3)^(2*x3(2));
    diffv3 = nabla*IFI3*nabla';
%%
diff1=3600*.25*x1(1).^2*x1(3).^(2*x1(2)); % diffusivities
diff2=3600*.25*x2(1).^2*x2(3).^(2*x2(2));
diff3=3600*.25*x3(1).^2*x3(3).^(2*x3(2));
damp1=x1(3)*pi/12; % damping values
damp2=x2(3)*pi/12;
damp3=x3(3)*pi/12;
[damp1 damp2 damp3] % slopes in Table 2
sqrt([IFI1(3,3) IFI2(3,3) IFI3(3,3)])*pi/12 % standard errors just from Hessian
sqrt([IFI1b(3,3) IFI2b(3,3) IFI3(3,3)])*pi/12 % standard errors in Table 2
[2*x1(2) 2*x2(2) 2*x3(2)] % slopes in Table 2
2*sqrt([IFI1(2,2) IFI2(2,2) IFI3(2,2)]) % standard errors just from Hessian
2*sqrt([IFI1b(2,2) IFI2b(2,2) IFI3(2,2)]) % standard errors in Table 2
[diff1 diff2 diff3] % diffusivities in Table 2
sqrt([diffv1 diffv2 diffv3])*3600 % standard errors just from Hessian
sqrt([diffv1b diffv2b diffv3])*3600 % standard errors in Table 2
%%
end
[time1' time2' time3'] % CPU times