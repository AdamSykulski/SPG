function [out4] = VarQuad(x2,omega1,omega2,N)
omegaR = -pi:0.01:pi;
MaternSpec = x2(1)^2./((1/x2(3))^2+omegaR.^2).^x2(2);
DK1 = sin(N*(omega1-omegaR)/2)./sin((omega1-omegaR)/2).*exp(-1i*(omega1-omegaR)*(N+1)/2);
DK2 = sin(N*(omega2-omegaR)/2)./sin((omega2-omegaR)/2).*exp(-1i*(omega2-omegaR)*(N+1)/2);
out4=abs(sum(MaternSpec.*DK1.*conj(DK2))/(N*length(omegaR)))^2;