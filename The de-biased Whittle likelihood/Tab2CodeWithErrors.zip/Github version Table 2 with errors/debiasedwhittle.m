function [param]=debiasedwhittle(x,SX,N)
x=max(0,x); x(2)=max(0.5,x(2)); x(3) = 1/x(3);
acv=maternacvs(x,N,1); % autocovariance sequence
ESF2=2*fft(acv.*(1-(0:N-1)/N))-acv(1); ESF3=abs(real(ESF2(1:601))); % expected periodogram
% debiased Whittle likelihood
param=2*(sum(log(ESF3))+sum(SX./ESF3));