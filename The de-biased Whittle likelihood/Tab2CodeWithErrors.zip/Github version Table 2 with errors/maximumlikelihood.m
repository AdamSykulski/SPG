function [out]=maximumlikelihood(x,X,Y,N)
X1=X(1:2:end); Y1=Y(1:2:end);
X2=X(2:2:end); Y2=Y(2:2:end);
tt=-(N-1):2*N-1;
htt=exp(1i*pi*tt/2).*sin(pi*tt/2)./(tt*pi);
htt(N)=0.5;
x(2)=max(0.50001,x(2)); x(2) = min(1.5,x(2)); x(3) = min(abs(x(3)),N/(2*pi)); x(3) = 1/x(3);
tpz2 = maternacvs(abs(x),N,1); % autocovariance sequence
mtt = [tpz2(N:-1:1) tpz2(2:N)];
for jj = 1:N
    mwtt(jj) = sum(mtt.*htt(jj+N-1+N-1:-1:jj));
end
mwtt=0.5*mwtt(1:2:end);
C1=toeplitz(real(mwtt));
C2=toeplitz([0 -imag(mwtt(2:end))],[0 imag(mwtt(2:end))]);
C3=transpose(C2);
C4=C1;
L = chol([C1 C2; C3 C4]);
logdetC = 2*sum(log(diag(L)));
out=0.5*logdetC+0.5*([X1; Y1]'/L)*(L'\[X1; Y1])+0.5*logdetC+0.5*([X2; Y2]'/L)*(L'\[X2; Y2]);