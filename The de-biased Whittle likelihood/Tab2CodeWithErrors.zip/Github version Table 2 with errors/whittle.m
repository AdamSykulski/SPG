function [param]=whittle(x,SX,N)
x(3) = 1/x(3);
omega=(0:2*pi/N:pi);
ESF3=x(1).^2./(omega.^2+x(3).^2).^x(2);
% Whittle likelihood
param=2*(sum(log(ESF3))+sum(SX./ESF3));