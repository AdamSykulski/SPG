N = 1200; %length of time series (50 days of hourly observations)
omega=(0:1/N:.5)*24; % fourier frequencies in cycles per day
load drifterdata.mat % load the data
options=optimset('GradObj','on'); % Fminsearch choices
xb=[.05 1 .1]; % initial Matern values
figure;
for ii = 1:3 % cycle through drifters (Atlantic/Pacific/Indian)
    XX=reshape(drifterdata(ii,1,:),N,1); % longitudinal position of drifter ii
    YY=reshape(drifterdata(ii,2,:),N,1); % latitudinal position of drifter ii
    Z=reshape(drifterdata(ii,3,:),N,1); % complex velocities of drifter ii
    if ii == 1
        Z = conj(Z); % for the Atlantic drifter the inertial side of the spectrum is on the positive side, so we take the conjugate to flip this
    end
    JZ = fft(Z)/sqrt(N); SZ = (abs(JZ)).^2; % periodogram
    SZ1=SZ(1:floor(N/2)+1); % non-inertial side of the spectrum
    SZ2 = [SZ(1); SZ(end:-1:ceil(N/2)+1)]; % inertial side of the spectrum
    x1b=fminsearchbnd(@(x) debiasedwhittle(x,xb,SZ1',N),[1 1 1],[0 0.5001/xb(2) (1/N)/xb(3)],[inf 2.5/xb(2) inf],options); % debiased whittle fit
    x1 = x1b.*xb; % scale back to correct units
    acv=maternacvs(x1,N,1); % autocovariance sequence
    ESF2=2*fft(acv.*(1-(0:N-1)/N))-acv(1); ESF3=abs(real(ESF2(1:601))); % expected periodogram
    % code to exactly reproduce figure follows
    if ii == 1        
        subplot(3,3,1); plot(XX+1i.*YY); axis equal; ylabel('lat'); xlabel('lon'); title('Atlantic');
        set(gca,'ytick',[-27.5 -27]); set(gca,'xtick',[358.5 359]); grid on
        subplot(3,3,4); plot([1/24:1/24:N/24], real(Z),'r'); xlim([0 N/24]);
        hold on; plot([1/24:1/24:N/24], imag(Z),'--'); xlim([0 N/24]); ylabel('m/s'); xlabel('day'); ylim([-1.05 1.05]);
        subplot(3,3,7); loglog(omega,3600*SZ1'*10^0.25,'r'); hold on; loglog(omega,3600*SZ2'*10^0.25,'--');
        hold on; loglog(omega,3600*ESF3','k')
        xlim([0 12]); ylim([10^-1 0.6*10^6]); xlabel('cycles per day'); ylabel('m^2/s');
        set(gca,'xtick',[.1 .5 1 3 12]); set(gca,'ytick',[10^0 10^2 10^4]);
    elseif ii == 2
        subplot(3,3,2); plot(XX+1i.*YY); axis equal; xlabel('lon'); title('Pacific');
        set(gca,'ytick',17:18); set(gca,'xtick',246:248); grid on
        subplot(3,3,5); plot([1/24:1/24:N/24], real(Z),'r'); xlim([0 N/24]);
        hold on; plot([1/24:1/24:N/24], imag(Z),'--'); xlim([0 N/24]); xlabel('day'); ylim([-1.05 1.05]);
        subplot(3,3,8); loglog(omega,3600*SZ1'*10^0.25,'r'); hold on; loglog(omega,3600*SZ2'*10^0.25,'--');
        hold on; loglog(omega,3600*ESF3','k')
        xlim([0 12]); ylim([10^-1 0.6*10^6]); xlabel('cycles per day')
        set(gca,'xtick',[.1 .5 1 3 12]); set(gca,'ytick',[10^0 10^2 10^4]);
    else
        subplot(3,3,3); plot(XX+1i.*YY); axis equal; xlabel('lon'); title('Indian');
        set(gca,'ytick',4:8); set(gca,'xtick',88:94); grid on
        subplot(3,3,6); plot([1/24:1/24:N/24], real(Z),'r'); xlim([0 N/24]);
        hold on; plot([1/24:1/24:N/24], imag(Z),'--'); xlim([0 N/24]); xlabel('day'); ylim([-1.05 1.05]);
        subplot(3,3,9); loglog(omega,3600*SZ1'*10^0.25,'r'); hold on; loglog(omega,3600*SZ2'*10^0.25,'--'); 
        hold on; loglog(omega,3600*ESF3','k')
        xlim([0 12]); ylim([10^-1 0.6*10^6]); xlabel('cycles per day')
        set(gca,'xtick',[.1 .5 1 3 12]); set(gca,'ytick',[10^0 10^2 10^4]);
    end
end