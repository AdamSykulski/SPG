N = 1200; %length of time series (50 days of hourly observations)
load drifterdata.mat % load the data
options=optimset('GradObj','on'); % Fminsearch choices
xb=[.05 1 .1]; % initial Matern values
for ii = 1:3 % cycle through drifters (Atlantic/Pacific/Indian)
    Z=reshape(drifterdata(ii,3,:),N,1); % complex velocities of drifter ii
    if ii == 1
        Z = conj(Z); % for the Atlantic drifter the inertial side of the spectrum is on the positive side, so we take the conjugate to flip this
    end
    %% MAXIMUM LIKELIHOOD
    tic; % using fminsearchbnd, the parameters are rescaled to all start at 1, lower and upper bounds as permitted by the stochastic process
    Z1=0.5*(hilbert(real(Z))+1i.*hilbert(imag(Z)));
    x1=fminsearchbnd(@(x) maximumlikelihood(x,real(Z1),imag(Z1),N,1),xb,[0 0.5001 (10/N)],[inf 2.5 inf],options);
    time1=toc;    
    %% DEBIASED WHITTLE
    tic; % using fminsearchbnd, the parameters are rescaled to all start at 1, lower and upper bounds as permitted by the stochastic process
    JZ = fft(Z)/sqrt(N); SZ = (abs(JZ)).^2; % periodogram
    SZ1=SZ(1:floor(N/2)+1); % non-inertial side of the spectrum
    x1b=fminsearchbnd(@(x) debiasedwhittle(x,xb,SZ1',N),[1 1 1],[0 0.5001/xb(2) (1/N)/xb(3)],[inf 2.5/xb(2) inf],options);
    x2 = x1b.*xb; % scale back to correct units
    time2=toc;
    %% STANDARD WHITTLE
    tic; % using fminsearchbnd, the parameters are rescaled to all start at 1, lower and upper bounds as permitted by the stochastic process
    JZ = fft(Z)/sqrt(N); SZ = (abs(JZ)).^2; % periodogram
    SZ1=SZ(1:floor(N/2)+1); % non-inertial side of the spectrum
    x2b=fminsearchbnd(@(x) whittle(x,xb,SZ1',N),[1 1 1],[0 0.5001/xb(2) (1/N)/xb(3)],[inf 2.5/xb(2) inf],options);
    x3 = x2b.*xb; % scale back to correct units
    time3=toc;    
%%
diff1=3600*.25*x1(1).^2./(x1(3).^(2*x1(2))); % diffusivities in m^2/s
diff2=3600*.25*x2(1).^2./(x2(3).^(2*x2(2)));
diff3=3600*.25*x3(1).^2./(x3(3).^(2*x3(2)));
damp1=1/(x1(3)*12/pi); % damping in days
damp2=1/(x2(3)*12/pi);
damp3=1/(x3(3)*12/pi);
ii
[damp1 damp2 damp3] % damping parameters for drifter ii
[2*x1(2) 2*x2(2) 2*x3(2)] % slope parameters for drifter ii
[diff1 diff2 diff3] % diffusivity values for drifter ii
[time1 time2 time3] % simulation runtimes for drifter ii
%%
end