function [param]=debiasedwhittle(x,xb,SX,N)
% Computes the value of the debiased Whittle likelihood for value x.*xb (rescaled
% back to normal units) for periodogram SX, data length N
x=max(0,x); x(2)=max(0.5/xb(2),x(2)/xb(2));
acv=maternacvs(x.*xb,N,1); % autocovariance sequence
ESF2=2*fft(acv.*(1-(0:N-1)/N))-acv(1); ESF3=abs(real(ESF2(1:601))); % expected periodogram
% debiased Whittle likelihood
param=sum(log(ESF3))+sum(SX./ESF3);