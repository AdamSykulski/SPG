function [param]=whittle(x,xb,SX,N)
% Computes the value of the Whittle likelihood for value x.*xb (rescaled
% back to normal units) for periodogram SX, data length N
omega=(0:2*pi/N:pi);
xx=x.*xb;
ESF3=xx(1).^2./(omega.^2+xx(3).^2).^xx(2);
% Whittle likelihood
param=sum(log(ESF3))+sum(SX./ESF3);